------------------------------------------------------------
Free Pixel Battle Backgrounds + Free Pixel Characters
------------------------------------------------------------

Contents:
6 pixel-style battle backgrounds.
2 demo scenes.
6 sample enemies+ 1 sample hero.

If you need more pixel battle backgrounds, please visit the following asset pack:
Pixel Battle Backgrounds - Pack 1 (https://assetstore.unity.com/packages/slug/284626)
Pixel Battle Backgrounds - Pack 2 (https://assetstore.unity.com/packages/slug/286408)
Pixel Battle Backgrounds - Pack 3 (https://assetstore.unity.com/packages/slug/286411)
410 Pixel Battle Backgrounds BUNDLE (https://assetstore.unity.com/packages/slug/288183)

If you need more pixel enemy sprites, please visit the following asset pack:
Pixel Enemies Pack (https://assetstore.unity.com/packages/slug/284735)